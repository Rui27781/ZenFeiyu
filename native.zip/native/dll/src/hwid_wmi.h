#pragma once

#include <windows.h>

// WMI-level HWID spoof for the injected Minecraft process.
//
// Background: some servers/anticheat read the machine fingerprint through WMI
// (e.g. `Win32_ComputerSystemProduct.UUID` / `SerialNumber`), NOT through
// RegQueryValueExW. WMI queries execute inside the *game process* as COM
// (IWbemLocator -> IWbemServices::ExecQuery -> IEnumWbemClassObject ->
// IWbemClassObject::Get), even though the actual SMBIOS read happens in a
// separate WmiPrvSE.exe provider process. So the only place we can intercept
// is the COM layer inside the game process, before results are handed back.
//
// Strategy (deliberately low-footprint):
//   * IAT-patch `CoCreateInstance` in the game's own modules (NOT ole32's
//     code page) so that when anyone creates CLSID_WbemLocator we hand out a
//     thin proxy wrapping the real IWbemLocator.
//   * The proxy chain (IWbemLocator -> IWbemServices -> IEnumWbemClassObject
//     -> IWbemClassObject) forwards every vtable method to the real object,
//     except IWbemClassObject::Get: the object's own __CLASS decides which
//     fake is returned, so Win32_BIOS / Win32_BaseBoard / Win32_DiskDrive each
//     report a different serial instead of one shared value.
//   * If the IAT patch finds no importer, we silently disable (default OFF).
//
// This complements hwid_hook.cpp (registry path). Between the two, classic
// fingerprint surfaces - registry MachineGuid/ProductId and WMI
// ComputerSystemProduct UUID/Serial - are both covered.

namespace hwid {

// Install the WMI COM spoof. >0 = modules patched, 0 = armed for modules that
// load later, -1 = nothing could be armed.
int install_wmi();

} // namespace hwid
