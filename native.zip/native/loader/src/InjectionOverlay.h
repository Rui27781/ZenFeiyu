#pragma once

#include <QElapsedTimer>
#include <QString>
#include <QWidget>

class QPropertyAnimation;

namespace loader {

// Modal-style frameless overlay shown while injection runs. Drives a
// spinner + progress bar, then a checkmark (or X) when the inject worker
// thread reports back. After a short hold it fades out and emits
// completed(); the application's main wires that to QCoreApplication::quit.
class InjectionOverlay : public QWidget {
    Q_OBJECT
    Q_PROPERTY(qreal spinnerAngle      READ spinnerAngle      WRITE setSpinnerAngle)
    Q_PROPERTY(qreal progress          READ progress          WRITE setProgress)
    Q_PROPERTY(qreal panelOpacity      READ panelOpacity      WRITE setPanelOpacity)
    Q_PROPERTY(qreal checkmarkProgress READ checkmarkProgress WRITE setCheckmarkProgress)
    Q_PROPERTY(qreal textReveal        READ textReveal        WRITE setTextReveal)

public:
    InjectionOverlay(unsigned long pid, const QString& target,
                     const QString& commandLine,
                     QWidget* parent = nullptr);

    void start();

    qreal spinnerAngle()      const { return spinnerAngle_; }
    qreal progress()          const { return progress_; }
    qreal panelOpacity()      const { return panelOpacity_; }
    qreal checkmarkProgress() const { return checkmarkProgress_; }
    qreal textReveal()        const { return textReveal_; }

    void setSpinnerAngle(qreal v)      { spinnerAngle_      = v; update(); }
    void setProgress(qreal v)          { progress_          = v; update(); }
    void setPanelOpacity(qreal v)      { panelOpacity_      = v; update(); }
    void setCheckmarkProgress(qreal v) { checkmarkProgress_ = v; update(); }
    void setTextReveal(qreal v)        { textReveal_        = v; update(); }

signals:
    void completed(bool success, unsigned long pid);

protected:
    void paintEvent(QPaintEvent*) override;

private:
    void onInjectResult(QString err);
    void playFinishSequence();

    unsigned long pid_;
    QString       target_;
    QString       commandLine_;
    QString       statusText_       = QStringLiteral("Injecting ZenFeiyu…");

    qreal spinnerAngle_      = 0.0;
    qreal progress_          = 0.0;
    qreal panelOpacity_      = 0.0;
    qreal checkmarkProgress_ = 0.0;
    qreal textReveal_        = 0.0;

    bool    injectDone_ = false;
    bool    injectOk_   = false;
    QString injectErr_;

    // Enforces a minimum on-screen time so a fast injection does not just
    // flash the overlay before the reveal animation has played.
    QElapsedTimer shownTimer_;

    QPropertyAnimation* spinnerAnim_  = nullptr;
    QPropertyAnimation* progressAnim_ = nullptr;
};

} // namespace loader
